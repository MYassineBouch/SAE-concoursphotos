<?php require('views/blocks/header.php') ?>

<h2>VOUS ETES ADMIN, VOUS NE POUVEZ PAS PARTICIPER</h2>

<?php require('./views/blocks/footer.php');?>