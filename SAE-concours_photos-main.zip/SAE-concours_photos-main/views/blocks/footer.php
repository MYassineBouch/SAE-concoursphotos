<footer>
    <div class="footer-content">
        <img class="footer-img" src="./layout/images/rt.png" alt="R&T">
        <img class="footer-img" src="./layout/images/iut.png" alt="IUT">
        <div class="footer-text">
            BUT1 Réseaux & Télécommunications - Groupe TP2 - <a href="https://iutp.univ-poitiers.fr/liut-poitiers-niort-chatellerault/les-sites-de-formation/chatellerault/">Châtellerault</a>
        </div>
    </div>
</footer>
</body>

</html>