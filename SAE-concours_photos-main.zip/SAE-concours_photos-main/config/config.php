<?php
define('HOST', '192.168.156.221'); # serveur où sera stocké la base des données
define('DB', 'tp2_photo'); # nom de la base
define('USER', 'mbouch46'); # utilisateur (admin)
define('PASSWORD', 'rt2324'); # mot de passe

